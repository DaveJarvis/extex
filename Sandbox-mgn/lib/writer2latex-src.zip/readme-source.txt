Writer2LaTeX source version 0.4.1d (2006-11-02)
===============================================

Writer2LaTeX is (c) 2002-2006 by Henrik Just.
The source is available under the terms and conditions of the
GNU LESSER GENERAL PUBLIC LICENSE, version 2.1.
Please see the file COPYING.TXT for details.

Currently parts of the source for Writer2LaTeX is somewhat messy and
undocumented. This situation is improving from time to time :-)

Building Writer2LaTeX
---------------------

Writer2LaTeX uses Ant version 1.5 or later (http://ant.apache.org) to build.


Some java libraries from OOo are needed to build the filter part of Writer2LaTeX,
these are jurt.jar, unoil.jar, ridl.jar and juh.jar.

To make these files available for the compiler, edit the file build.xml in
the writer2latex041 directory as follows:

The line
	<property name="OFFICE_HOME" location=""/>
should be edited to contain the path to your OOo installation, e.g.
	<property name="OFFICE_HOME" location="C:/Program Files/OpenOffice.org 2.0.4"/>


To build, open a command shell, navigate to the writer2latex041 directory and type

ant package

(this assumes, that ant is in your path; otherwise specifify the full path.)

In addition to package, the build file supports these targets:
    all
        Build nearly everything
    compile
        Compile all file except the tests.        
    jar
        Create the jar file.
    package
        Create extension package for OOo
    javadoc
        Create the javadoc documentation in target/javadoc. 
    clean


Henrik Just, November 2006


Thanks to Michael Niedermair for writing the ant build file

