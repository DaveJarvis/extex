/************************************************************************
 *
 *  CaptionConverter.java
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License version 2.1, as published by the Free Software Foundation.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *  MA  02111-1307  USA
 *
 *  Copyright: 2002-2007 by Henrik Just
 *
 *  All Rights Reserved.
 * 
 *  Version 0.4.1e (2007-03-06)
 *
 */
 
package writer2latex.latex;

import org.w3c.dom.Element;
import org.w3c.dom.Node;

import writer2latex.latex.util.Context;
import writer2latex.office.OfficeReader;
import writer2latex.office.XMLString;
import writer2latex.util.Config;

/**
 *  <p>This class converts captions (for figures and tables) to LaTeX.</p>
 *  <p>Packages:
 *  <ul><li>caption2.sty is used implement non-floating captions</li></ul>
 *  <p>Options:
 *  <ul><li>use_caption2 is a boolean option to determine whether or not
 *  to use caption2.sty. If this option is set to false, a simple definition of
 *  \captionof (borrowed from capt-of.sty) is inserted in the preamble</li></ul>
 *  <p>TODO: Implement formatting of captions using the features of caption2.sty
 *  (only if formatting>=CONVERT_MOST)
 */
public class CaptionConverter extends ConverterHelper {

    private boolean bNeedCaptionOf = false;
	
    private Element seqField = null; // the sequence field within the current caption

    public CaptionConverter(OfficeReader ofr, Config config, ConverterPalette palette) {
        super(ofr,config,palette);
    }

    public void appendDeclarations(LaTeXDocumentPortion pack, LaTeXDocumentPortion decl) {
        if (bNeedCaptionOf) {
            if (config.useCaption2()) {
                pack.append("\\usepackage{caption2}").nl();
            }
            else {
                decl.append("% Non-floating captions").nl()
                    .append("\\makeatletter").nl()
                    .append("\\newcommand\\captionof[1]{\\def\\@captype{#1}\\caption}").nl()
                    .append("\\makeatother").nl();
            }
        }
    }
	
    /**
     * <p> Process a text:p tag as a caption</p>
     *  @param <code>node</code> The text:p element node containing the caption
     *  @param <code>ldp</code> The <code>LaTeXDocumentPortion</code> to add LaTeX code to
     *  @param <code>oc</code> The current context
     */
    public void handleCaption(Element node,LaTeXDocumentPortion ldp, Context oc) {
        // Get rid of the caption label before converting
        removeCaptionLabel(node,0);	
        Element label = seqField;
        seqField = null;

        // Get the stylename of the paragraph and push the font used
        String sStyleName = node.getAttribute(XMLString.TEXT_STYLE_NAME);
        palette.getI18n().pushSpecialTable(palette.getParCv().getFontName(sStyleName));
		
        // Floating frames should be positioned *above* the label, hence
        // we use a separate ldp for the paragraphs and at this later
        LaTeXDocumentPortion ldppar = new LaTeXDocumentPortion(true);

        // Convert the caption
        if (oc.isInFigureFloat() || oc.isInTableFloat()) {
            ldppar.append("\\caption");
        }
        else {
            boolean bIsTableCaption = ofr.isTableSequenceName(ofr.getSequenceName(node));

            bNeedCaptionOf = true;
            ldppar.append("\\captionof{")
                  .append(bIsTableCaption? "table" : "figure")
                  .append("}");
        }

        if (palette.getHeadingCv().containsElements(node)) {
            ldppar.append("[");
            palette.getInlineCv().traversePlainInlineText(node,ldppar,oc);
            ldppar.append("]");
        }
        // Update context before traversing text
        Context ic = (Context) oc.clone();
        ldppar.append("{");
        palette.getInlineCv().traverseInlineText(node,ldppar,ic,false);
        ldppar.append("}").nl();

        // Insert label
        palette.getFieldCv().handleSequence(label,ldppar,oc);

        // Flush any floating frames
        palette.getDrawCv().flushFloatingFrames(ldp,oc);
		
        ldp.append(ldppar);

        // Flush any index marks
        palette.getIndexCv().flushIndexMarks(ldp,oc);

        // pop the font name
        palette.getI18n().popSpecialTable();

    }
	
    // In OpenDocument a caption is an ordinary paragraph with a text:seqence
    // element. For example
    // Table <text:sequence>3</text:sequence>: Caption text
    // The first part is the caption label which is autogenerated by LaTeX.
    // Before converting, we remove this in 3 steps:
    //   nStep = 0: Remove all text before the text:sequence
    //   nStep = 1: Remove all text up to the first alphanumeric character
    //              after the text:sequence
    //   nStep = 2: Finished!
    private int removeCaptionLabel(Element node, int nStep) {
        if (nStep==2) { return 2; }

        Node removeMe = null;

        Node child = node.getFirstChild();
        while (child!=null) {
            if (child.getNodeType()==Node.ELEMENT_NODE) {
                if (nStep==0 && child.getNodeName().equals(XMLString.TEXT_SEQUENCE)) {
                    removeMe = child; 
                    seqField = (Element) child; // remember me...
                    nStep = 1;
                }
                else if (nStep<2 && !ofr.isDrawElement(child)) {
                    // draw elements (frames) should not be touched..
                    nStep = removeCaptionLabel((Element)child,nStep);
                }
            }
            else if (child.getNodeType()==Node.TEXT_NODE) {
                if (nStep==0) {
                    child.setNodeValue("");
                }
                else if (nStep==1) {
                    String s = child.getNodeValue();
                    int n = s.length();
                    for (int j=0; j<n; j++) {
                        if (Character.isLetterOrDigit(s.charAt(j))) {
                            child.setNodeValue(s.substring(j));
                            nStep = 2;
                            break;
                        }
	                }
                }
            }
            child = child.getNextSibling();
        }

        if (removeMe!=null) { node.removeChild(removeMe); }
        return nStep;
    }
	

}