/************************************************************************
 *
 *  TableConverter.java
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License version 2.1, as published by the Free Software Foundation.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *  MA  02111-1307  USA
 *
 *  Copyright: 2002-2007 by Henrik Just
 *
 *  All Rights Reserved.
 * 
 *  Version 0.4.1e (2007-03-06)
 *
 */

package writer2latex.latex;

import org.w3c.dom.Element;
import writer2latex.util.*;
import writer2latex.office.*;
import writer2latex.latex.util.BeforeAfter;
import writer2latex.latex.util.Context;

/** <p>This class creates LaTeX code from OOo table styles.
 */
public class TableConverter extends ConverterHelper {

    private boolean bNeedLongtable = false;
    private boolean bNeedSupertabular = false;
    private boolean bNeedTabulary = false;
    private boolean bContainsTables = false;
	
    /** <p>Constructs a new <code>TableConverter</code>.</p>
     */
    public TableConverter(OfficeReader ofr, Config config,
        ConverterPalette palette) {
        super(ofr,config,palette);
    }

    public void appendDeclarations(LaTeXDocumentPortion pack, LaTeXDocumentPortion decl) {
        pack.append("\\usepackage{array}").nl();
        if (bNeedLongtable) { pack.append("\\usepackage{longtable}").nl(); }
        if (bNeedSupertabular) { pack.append("\\usepackage{supertabular}").nl(); }
        if (bNeedTabulary) { pack.append("\\usepackage{tabulary}").nl(); }
        // Set padding for table cells (1mm is default in OOo!)
        // For vertical padding we can only specify a relative size
        if (bContainsTables) {
            decl.append("\\setlength\\tabcolsep{1mm}").nl();
            decl.append("\\renewcommand\\arraystretch{1.3}").nl();
        }
    }
	
    /** <p> Process a table (table:table or table:sub-table tag)</p>
     * @param <code>node</code> The element containing the table
     * @param <code>ldp</code> the <code>LaTeXDocumentPortion</code> to which
     * LaTeX code should be added
     * @param <code>oc</code> the current context
     */
    public void handleTable(Element node, LaTeXDocumentPortion ldp, Context oc) {
        // Read the table
        TableReader table = new TableReader(ofr,node);
		
        // Update the context
        Context ic = (Context) oc.clone();
        ic.setInTable(true);
		
        // Get formatter and update flags according to formatter
        TableFormatter formatter = new TableFormatter(ofr,table,!ic.isInMulticols(),oc.isInTable(),config);
        bContainsTables = true;
        bNeedLongtable |= formatter.isLongtable();
        bNeedSupertabular |= formatter.isSupertabular();
        bNeedTabulary |= formatter.isTabulary();
			
        ic.setInSimpleTable(formatter.isSimple());

        // We may need a hyperlink target
        if (!table.isSubTable()) {
            palette.getFieldCv().addTarget(node,"|table",ldp);
        }
		
        // Export table declaration (except supertabular)
        BeforeAfter baTable = new BeforeAfter();
        formatter.applyTableStyle(baTable);
        if (!formatter.isSupertabular()) {
            ldp.append(baTable.getBefore()).nl();
        }
		
        // Get number of rows and columns
        int nRowCount = table.getRowCount();
        int nColCount = table.getColCount();
        int nFirstBodyRow = table.getFirstBodyRow();
		
        // Never allow footnotes in tables
        // (longtable.sty *does* allow footnotes in body, but not in head -
        // only consistent solution is to disallow all footnotes)
        ic.setNoFootnotes(true);

        // Export table head
        if (formatter.isSupertabular()) {
            ldp.append("\\tablehead{");
        }

        if (nFirstBodyRow>0) {
            // Add interrow material before first row:
            String sInter = formatter.getInterrowMaterial(0);
            if (sInter.length()>0) { 
                ldp.append(sInter).nl();
            }
        }

        for (int nRow=0; nRow<nFirstBodyRow; nRow++) {
            // Export columns in this row
            int nCol = 0;
            while (nCol<nColCount) {
                Element cell = (Element) table.getCell(nRow,nCol);
                if (XMLString.TABLE_TABLE_CELL.equals(cell.getNodeName())) {
                    BeforeAfter baCell = new BeforeAfter();
                    formatter.applyCellStyle(nRow,nCol,baCell);
                    ldp.append(baCell.getBefore());
                    if (nCol==nColCount-1) { ic.setInLastTableColumn(true); }
                    palette.getBlockCv().traverseBlockText(cell,ldp,ic);
                    ic.setInLastTableColumn(false);
                    ldp.append(baCell.getAfter());
                }
                // Otherwise ignore; the cell is covered by a \multicolumn entry.
                // (table:covered-table-cell)
                int nColSpan = Misc.getPosInteger(cell.getAttribute(
                                   XMLString.TABLE_NUMBER_COLUMNS_SPANNED),1);
                if (nCol+nColSpan<nColCount) {
                    if (formatter.isSimple()) { ldp.append(" & "); }
                    else { ldp.append(" &").nl(); }
                }
                nCol+=nColSpan;
            }
            ldp.append("\\\\").append(formatter.getInterrowMaterial(nRow+1));
            if (nRow<nFirstBodyRow-1) { ldp.nl(); }
        }
		
        if (formatter.isSupertabular()) {
            ldp.append("}").nl();
            ldp.append(baTable.getBefore()).nl();
        }
        else if (formatter.isLongtable()) {		
            ldp.nl().append("\\endhead").nl();
        }
        else if (nFirstBodyRow>0) {
            ldp.nl();
        }
		
        // Export table body
        if (nFirstBodyRow==0) {
            // Add interrow material before first row:
            String sInter = formatter.getInterrowMaterial(0);
            if (sInter.length()>0) { 
                ldp.append(sInter).nl();
            }
        }

        for (int nRow=nFirstBodyRow; nRow<nRowCount; nRow++){
            // Export columns in this row
            int nCol = 0;
            while (nCol<nColCount) {
                Element cell = (Element) table.getCell(nRow,nCol);
                if (XMLString.TABLE_TABLE_CELL.equals(cell.getNodeName())) {
                    BeforeAfter baCell = new BeforeAfter();
                    formatter.applyCellStyle(nRow,nCol,baCell);
                    ldp.append(baCell.getBefore());
                    if (nCol==nColCount-1) { ic.setInLastTableColumn(true); }
                    palette.getBlockCv().traverseBlockText(cell,ldp,ic);
                    ic.setInLastTableColumn(false);
                    ldp.append(baCell.getAfter());
                }
                // Otherwise ignore; the cell is covered by a \multicolumn entry.
                // (table:covered-table-cell)
                int nColSpan = Misc.getPosInteger(cell.getAttribute(
                                   XMLString.TABLE_NUMBER_COLUMNS_SPANNED),1);
                if (nCol+nColSpan<nColCount) {
                    if (formatter.isSimple()) { ldp.append(" & "); }
                    else { ldp.append("&").nl(); }
                }
                nCol+=nColSpan;
            }
            ldp.append("\\\\").append(formatter.getInterrowMaterial(nRow+1)).nl();
        }

        // End table
        ldp.append(baTable.getAfter()).nl();
		
        // Insert any pending footnotes
        palette.getNoteCv().flushFootnotes(ldp,oc);
    }

    
}
