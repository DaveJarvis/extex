/************************************************************************
 *
 *  CellStyleConverter.java
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License version 2.1, as published by the Free Software Foundation.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston,
 *  MA  02111-1307  USA
 *
 *  Copyright: 2002-2007 by Henrik Just
 *
 *  All Rights Reserved.
 * 
 *  Version 0.4.1e (2007-02-27)
 *
 */

package writer2latex.xhtml;

import writer2latex.office.OfficeReader;
import writer2latex.office.StyleWithProperties;
import writer2latex.office.XMLString;
import writer2latex.util.Config;
import writer2latex.util.CSVList;

/**
 * <p>This class converts OpenDocument cell styles to CSS2 styles.
 * Cells are formatted using box properties and alignment.</p>
 */
public class CellStyleConverter extends StyleConverterHelper {

    /** <p>Create a new <code>CellStyleConverter</code></p>
     *  @param ofr an <code>OfficeReader</code> to read style information from
     *  @param config the configuration to use
     *  @param converter the main <code>Converter</code> class
     *  @param nType the type of xhtml to use
     */
    public CellStyleConverter(OfficeReader ofr, Config config, Converter converter, int nType) {
        super(ofr,config,converter,nType);
        // Style maps for Cells are currently not supported.
        // (In OOo, cell styles are only supported by Calc) 
        this.styleMap = new XhtmlStyleMap();
        this.bConvertStyles = config.xhtmlTableFormatting()==Config.CONVERT_ALL || config.xhtmlTableFormatting()==Config.IGNORE_HARD;
        this.bConvertHard = config.xhtmlTableFormatting()==Config.CONVERT_ALL || config.xhtmlTableFormatting()==Config.IGNORE_STYLES;
    }

    /** <p>Get an OpenDocument Cell style with a specific style name
     *  @param sStyleName the name of the OpenDocument style
     *  @return the style
     */
    public StyleWithProperties getStyle(String sStyleName) {
        return ofr.getCellStyle(sStyleName);
    }
	
    /** <p>Create default tag name to represent a Cell object</p>
     *  @param style to use
     *  @return the tag name. If the style is null, a default result should be
     *  returned.
     */
    public String getDefaultTagName(StyleWithProperties style) {
        return "td";
    }
	
    /** <p>Convert formatting properties for a specific Cell style.</p>
     *  @param style the style to convert
     *  @param props the <code>CSVList</code> object to add information to
     *  @param bInherit true if properties should be inherited from parent style(s)
     */
    public void applyProperties(StyleWithProperties style, CSVList props, boolean bInherit) {
        // Apply "inner" box properties (no margins)
        getFrameSc().cssBorder(style,props,bInherit);
        getFrameSc().cssPadding(style,props,bInherit);
        getFrameSc().cssBackground(style,props,bInherit);
        // only relevant for spreadsheets
        getParSc().cssPar(style,props,bInherit); 
        getTextSc().cssTextCommon(style,props,bInherit);
        // Cell-specific properties (vertical alignment)
        cssCell(style,props,bInherit);
    }
	
    private void cssCell(StyleWithProperties style, CSVList props, boolean bInherit){
        // Vertical align: Some values fit with css
        String s = style.getProperty(XMLString.FO_VERTICAL_ALIGN,bInherit);
        if ("middle".equals(s)) { props.addValue("vertical-align","middle"); }
        else if ("bottom".equals(s)) { props.addValue("vertical-align","bottom"); }
        else if ("top".equals(s)) { props.addValue("vertical-align","top"); }
        else { // No value (or "automatic") is interpreted different for Calc and Writer:
            props.addValue("vertical-align", ofr.isSpreadsheet() ? "bottom" : "top");
        }
    }

}
